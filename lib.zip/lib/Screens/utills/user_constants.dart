class UserConstants {

  late String userLoggedIn = "userLoggedIn";
  late String userId = "userId" ;
  late String userGeoFence = "userGeoFence" ;
  late String userEmail = "userEmail" ;
  late String userName = "userName" ;
  late String userCompanyName = "companyName";

  late String checkInId = "checkInId" ;

}
