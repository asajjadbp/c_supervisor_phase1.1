class ImageValue {
  static const qualityValue = 35;
}
