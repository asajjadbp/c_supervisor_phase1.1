class ChartData {
  ChartData(this.x, this.y);
  final String x;
  final int y;
}